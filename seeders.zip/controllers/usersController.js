
const { User,Role } = require('../models')
/* const nodemailer = require("nodemailer"); */
/* const ejs = require("ejs"); */
const path = require("path");
const Op = require('sequelize').Op

require('dotenv').config()
const bcrypt = require('bcrypt');
const { where } = require('sequelize');
const secretkey = "token"

/* let transporter = nodemailer.createTransport({
    host: process.env.SMTP_SERVICE_HOST,
    port: process.env.SMTP_SERVICE_PORT,
    secure: process.env.SMTP_SERVICE_SECURE,
    service: 'gmail',
    auth: {
        user: process.env.SMTP_USER_NAME,
        pass: process.env.SMTP_USER_PASSWORD
    },
    tls: {
        // Uncomment the following line to see more detailed errors
        // secureProtocol: 'TLSv1_2_method', // Force a specific SSL/TLS version if necessary
        rejectUnauthorized: false // This bypasses the certificate check, use it only for debugging
    }
}); */
exports.create = async (req, res) => {

    try {
        let password = req.body.password;
        let roleWiseUsers
        if (req.body.departmentName == 'Admin' || req.body.departmentName == 'Instructor' || req.body.departmentName == 'Student' || req.body.departmentName == 'Guest/Viewer' || req.body.departmentName == 'Sale Team' || req.body.departmentName == 'Telecaller Department' || req.body.departmentName == 'Front Desk' || req.body.departmentName == 'Receptions Desk' || req.body.departmentName == 'Counselor Department' || req.body.departmentName == 'Account Department') {
            roleWiseUsers = 'Users Admin';
        } else if (req.body.departmentName == 'Telecaller Team') {
            roleWiseUsers = 'Sub Users';
        }
        let data = {
            name: req.body.name,
            userName: req.body.userName,
            phoneNumber: req.body.phoneNumber,
            email: req.body.email,
            password: await bcrypt.hash(password, 10),
            departmentName: req.body.departmentName,
            roleName: roleWiseUsers,
            assignToUsers: req.profile.id,
            image: req.file.filename,
            src: req.file.path,
            active: req.body.active
        }

        console.log(data)
        const users = await User.create(data)

        users.createdAt = null
        users.password = null
        users.updatedAt = null
        return res.status(200).json({
            users: users,
            success: true,
            message: "Users Created SuccessFully"
        })
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            error: error,
            success: false,
            message: "Users error"
        })
    }

}





exports.findOne = async (req, res) => {
    try {
        const users = await User.findOne({ where: { id: req.params.usersId },include: [  { model: Role }] });
        res.status(200).json({
            users: users,
            success: true,
            message: "get one users by ID"
        });
    } catch (error) {
        console.log(error)
        res.status(400).json({
            error: error,
            success: false,
            message: 'error in getting the users'
        });
    }
}

/* exports.findAll = async (req, res) => {
    try {
        const loggedInUserId = req.profile.id;
        let LeadGetAllowated = req.query.LeadGetAllowated
        console.log(LeadGetAllowated)
        const loggedInUser = await User.findOne({ where: { id: loggedInUserId } });
        let where
        if (LeadGetAllowated) {
            where = {
                departmentName: loggedInUser.departmentName, id: { [Op.ne]: loggedInUserId }
            }
        } else {
            where = { departmentName: loggedInUser.departmentName }
        }
        const users = await User.findAll({ where });
        console.log(users)
        res.status(200).json({
            users: users,
            success: true,
            message: "Successfully retrieved all users"
        });
    } catch (error) {
        console.error(error); // Using console.error for errors
        res.status(500).json({
            error: error.message,
            success: false,
            message: "Failed to retrieve users"
        });
    }
} */


exports.findAll = async (req, res) => {
    try {
        const loggedInUserId = req.profile.id;
        let LeadGetAllowated = req.query.LeadGetAllowated
        const loggedInUser = await User.findOne({ where: { id: loggedInUserId }, include: [  { model: Role }]});
        let where = {};
 
       // Check if LeadGetAllowated query parameter is present
        if (LeadGetAllowated) {
            if (loggedInUser.Role.Name === 'Telecaller Department' || loggedInUser.Role.Name  === 'Telecaller Team') {
                where = { assignToUsers: loggedInUser.id, id: { [Op.ne]: loggedInUserId } }
            }
        } else {

            if (loggedInUser.Role.Name  === 'Admin' || loggedInUser.Role.Name  === 'Sale Team'  || loggedInUser.Role.Name  === 'Front Desk') {
                where = { departmentId: loggedInUser.departmentId };
            } else if (loggedInUser.Role.Name === 'Telecaller Department' || loggedInUser.Role.Name === 'Telecaller Team') {
                where = { assignToUsers: loggedInUser.id }
            }
            else {
                if (loggedInUser.Role.Name === 'Super Admin') {
                    where = where;
                }
            }


        }
 
        const users = await User.findAll({ where , include: [  { model: Role }]});
        res.status(200).json({
            users: users,
            success: true,
            message: "Successfully retrieved all users"
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            error: error,
            success: false,
            message: "Failed to retrieve users"
        });
    }
};
exports.update = async (req, res) => {
    try {
        let roleWiseUsers
     /*    if (req.body.Role.Name == 'Admin' || req.body.Role.Name == 'Instructor' || req.body.Role.Name == 'Student' || req.body.Role.Name == 'Guest/Viewer' || req.body.Role.Name == 'Sale Team' || req.body.Role.Name == 'Telecaller Department' || req.body.Role.Name == 'Front Desk' || req.body.Role.Name == 'Receptions Desk' || req.body.Role.Name == 'Counselor Department' || req.body.Role.Name == 'Account Department') {
            roleWiseUsers = 'Users Admin';
        } else if (req.body.Role.Name == 'Telecaller Team') {
            roleWiseUsers = 'Sub Users';
        } */
        let data = {
            name: req.body.name,
            userName: req.body.userName,
            phoneNumber: req.body.phoneNumber,
            email: req.body.email,
            departmentId: req.body.departmentId,
            roleName: roleWiseUsers,
            assignToUsers: req.profile.id,
            /*   image: req.file.filename,
              src: req.file.path, */
            active: req.body.active
        }

        const users = await User.update(data, { where: { id: req.params.usersId } });
        res.status(200).json({
            users: users,
            success: true,
            message: "Update Successfully users"
        });
    } catch (error) {
        console.log(error)
        res.status(400).json({
            error: error,
            success: false,
            message: "error  While Update The users"
        });
    }

}

exports.delete = async (req, res) => {
    try {
        const users = await User.destroy({ where: { id: req.params.usersId } });
        res.status(200).json({
            users: users,
            success: true,
            message: "Delete Successfully users"
        });
    } catch (error) {
        res.status(400).json({
            error: error,
            success: false,
            message: 'users not found'
        });
    }
}

exports.rolefindAll = async (req, res) => {
    try {
        const roles = await User.findAll({ where: { roleName: ['Sale Team'] } });
        res.status(200).json({
            roles: roles,
            success: true,
            message: "get Data Successfully Roles"
        });
    } catch (error) {
        res.status(400).json({
            error: error,
            success: false,
            message: 'Roles not found'
        });
    }
}