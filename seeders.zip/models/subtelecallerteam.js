'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class SubUserTelecallerTeam extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  SubUserTelecallerTeam.init({
    name: {
      type: DataTypes.STRING
    },
    userName: {
      type: DataTypes.STRING
    },
    userparentId:{
      type: DataTypes.INTEGER
    },
    phoneNumber: {
      type: DataTypes.STRING
    },
    email: {
      type: DataTypes.STRING
    },
    password: {
      type: DataTypes.STRING
    },
    resentPassword: {
      type: DataTypes.STRING
    },
    passwordResetOtp: {
      type: DataTypes.STRING
    },
    expireToken: {
      type: DataTypes.STRING
    },
    roleName: {
      type: DataTypes.ENUM('Admin', 'Instructor', 'Student', 'Guest/Viewer','Sale Team','Telecaller Department','Front Desk','Receptions Desk','Counselor Department','Account Department'),
    },
    image: {
      type: DataTypes.STRING
    },
    src: {
      type: DataTypes.STRING
    },
    address: {
      type: DataTypes.STRING
    },
    message: {
      type: DataTypes.TEXT('long')
    },
    active:{
      type : DataTypes.BOOLEAN,  //default value is false if not mentioned otherwise
    }
  }, {
    sequelize,
    modelName: 'SubUserTelecallerTeam',
  });
  return SubUserTelecallerTeam;
};