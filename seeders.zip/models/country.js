'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Country extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
    }
  };

  Country.init({
    OfficeName: {
      field: 'OfficeName',
      type: DataTypes.STRING,
      allowNull: true
    },
    Pincode: {
      field: 'Pincode',
      type: DataTypes.INTEGER,
      allowNull: true
    },
    OfficeType: {
      field: 'OfficeType',
      type: DataTypes.STRING,
      allowNull: true
    },
    DeliveryStatus: {
      field: 'DeliveryStatus',
      type: DataTypes.STRING,
      allowNull: true
    },
    Division: {
      field: 'DivisionName',
      type: DataTypes.STRING,
      allowNull: true
    },
    Region: {
      field: 'RegionName',
      type: DataTypes.STRING,
      allowNull: true
    },
    Circle: {
      field: 'CircleName',
      type: DataTypes.STRING,
      allowNull: true
    },
    Block: {
      field: 'Taluk',
      type: DataTypes.STRING,
      allowNull: true
    },
    District: {
      field: 'Districtname',
      type: DataTypes.STRING,
      allowNull: true
    },
    State: {
      field: 'StateName',
      type: DataTypes.STRING,
      allowNull: true
    },
    Telephone: {
      field: 'Telephone',
      type: DataTypes.STRING,
      allowNull: true
    },
    RelatedSuboffice: {
      field: 'RelatedSuboffice',
      type: DataTypes.STRING,
      allowNull: true
    },
    RelatedHeadoffice: {
      field: 'RelatedHeadoffice',
      type: DataTypes.STRING,
      allowNull: true
    },
    Country: {
      field: 'Country',
      type: DataTypes.STRING,
      allowNull: true
    },
  }, {
    sequelize,
    modelName: 'Country',
    underscored: true,
  });
  Country.removeAttribute('id');
  Country.removeAttribute('createdAt');
  Country.removeAttribute('updatedAt');
  return Country;
};  