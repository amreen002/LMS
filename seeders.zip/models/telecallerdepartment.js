'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class TelecallerDepartment extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  TelecallerDepartment.init({
    date: {
      type: DataTypes.DATE
    },
    uniqueId: {
      type: DataTypes.INTEGER
    },
    enquiryId: {
      type: DataTypes.INTEGER
    },
    name: {
      type: DataTypes.STRING
    },
    roleId: {
      type: DataTypes.INTEGER
    },
    age: {
      type: DataTypes.INTEGER
    },
    phoneNumber: {
      type: DataTypes.BIGINT
    },
    email: {
      type: DataTypes.STRING
    },
    workingStatus: {
      type: DataTypes.STRING
    },
    leadPlatform: {
      type: DataTypes.STRING
    },
    telecallerPersonName: {
      type: DataTypes.STRING,
    },
    status: {
      type: DataTypes.ENUM('1st Call', '2nd Call', '3rd Call', '4rd Call', 'Not Responding (N/R)', 'Other'),
    },
    visitingDate: {
      type: DataTypes.STRING
    },
    address: {
      type: DataTypes.STRING
    },
    userRoleName: {
      type: DataTypes.STRING
    },
    visitDate:
    {
      type: DataTypes.DATE
    },
    remark: {
      type: DataTypes.TEXT('long')
    }
  

  }, {
    sequelize,
    modelName: 'TelecallerDepartment',
  });
  return TelecallerDepartment;
};