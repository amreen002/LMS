'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class SaleTeam extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      /*       this.belongsTo(models.product_type, {foreignKey: 'product_type_id'}) */
      // this.hasMany(models.User, {foreignKey : 'roleId'});
    }
  }
  SaleTeam.init({
    date: {
      type: DataTypes.DATE
    },
    name: {
      type: DataTypes.STRING
    },
    roleId: {
      type: DataTypes.INTEGER
    },
    age: {
      type: DataTypes.INTEGER
    },
    phoneNumber: {
      type: DataTypes.BIGINT
    },
    email: {
      type: DataTypes.STRING
    },
    workingStatus: {
      type: DataTypes.STRING
    },
    leadPlatform: {
      type: DataTypes.STRING
    },
    telecallerPersonName: {
      type: DataTypes.STRING,
    },
    status: {
      type: DataTypes.ENUM('1st Call', '2nd Call', '3rd Call', '4rd Call', 'Not Responding (N/R)', 'Other'),
    },
    address: {
      type: DataTypes.STRING
    },
    userRoleName: {
      type: DataTypes.STRING
    },

  }, {
    sequelize,
    modelName: 'SaleTeam',
  });
  return SaleTeam;
};