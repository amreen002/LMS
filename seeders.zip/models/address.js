'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Address extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      this.belongsTo(models.FrontDesk, {
        foreignKey: 'AddressableId',
        constraints: false,
        as: 'FrontDesk'
      });

    }
  };
  Address.init({
    AddressableType: {
      field: 'AddressableType',
      type: DataTypes.STRING,
      allowNull: false
    },
    AddressableId: {
      field: 'AddressableId',
      type: DataTypes.INTEGER,
      allowNull: false
    },
    AddressType: {
      field: 'AddressType',
      type: DataTypes.STRING,
      allowNull: false
    },
    PostalCode: {
      field: 'PostalCode',
      type: DataTypes.INTEGER,
      allowNull: true
    },
    Address: {
      field: 'Address',
      type: DataTypes.TEXT,
      allowNull: false
    },
    City: {
      field: 'City',
      type: DataTypes.STRING,
      allowNull: false
    },
    District: {
      field: 'District',
      type: DataTypes.STRING,
      allowNull: true
    },
    State: {
      field: 'State',
      type: DataTypes.STRING,
      allowNull: false
    },
    Country: {
      field: 'Country',
      type: DataTypes.STRING,
      allowNull: false
    },
    IsSame: {
      field: 'IsSame',
      type: DataTypes.BOOLEAN,
      allowNull: true
    },
    Area: {
      field: 'Area',
      type: DataTypes.STRING,
      allowNull: true
    },
  }, {
    sequelize,
    modelName: 'Address',
    underscored: true
  });
  return Address;
};