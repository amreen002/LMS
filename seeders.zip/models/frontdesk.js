'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class FrontDesk extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      this.hasMany(models.Address, {
        foreignKey: 'AddressableId',
        constraints: false,
        as: 'FrontDesk'
      });
    }
  }
  FrontDesk.init({
    date: {
      type: DataTypes.DATE
    },
    uniqueId: {
      type: DataTypes.INTEGER
    },
    enquiryId: {
      type: DataTypes.INTEGER
    },
    name: {
      type: DataTypes.STRING
    },
    gender: {
      type: DataTypes.ENUM('Female', 'Male', 'Other'),
    },
    currentAddress: {
      type: DataTypes.STRING
    },
    AddressableId: {
      field: 'AddressableId',
      type: DataTypes.INTEGER,
      allowNull: false
    },
    address: {
      type: DataTypes.STRING
    },
    Education: {
      field: 'Education',
      type: DataTypes.ENUM('Education', 'School', 'Graduation', 'Master', 'Any other Skill')
    },
    CoursesLookFor: {
      field: 'CoursesLookFor',
      type: DataTypes.ENUM('Courses Look For', 'Advanced Digital Marketing Course', 'Professional Digital Marketing Course', '45 Days Digital Marketing Course', 'Web Development Course', 'Python Language Course', 'Data Analytics Course', 'Data Science Course', 'App Development Course', 'Ethical Hacking Course')
    },
    AssignEnquiry: {
      field: 'AssignEnquiry',
      type: DataTypes.STRING
    },
    roleId: {
      type: DataTypes.INTEGER
    },
    age: {
      type: DataTypes.INTEGER
    },
    phoneNumber: {
      type: DataTypes.BIGINT
    },
    email: {
      type: DataTypes.STRING
    },
    workingStatus: {
      type: DataTypes.STRING
    },
    leadPlatform: {
      type: DataTypes.STRING
    },
    telecallerPersonName: {
      type: DataTypes.STRING,
    },
    status: {
      type: DataTypes.ENUM('1st Call', '2nd Call', '3rd Call', '4rd Call', 'Not Responding (N/R)', 'Other'),
    },
    visitingDate: {
      type: DataTypes.STRING
    },
    address: {
      type: DataTypes.STRING
    },
    userRoleName: {
      type: DataTypes.STRING
    },
    visitDate: {
      type: DataTypes.DATE
    },
    remark: {
      type: DataTypes.TEXT('long')
    }

  }, {
    sequelize,
    modelName: 'FrontDesk',
  });
  return FrontDesk;
};