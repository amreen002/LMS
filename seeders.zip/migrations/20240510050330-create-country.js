'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Countries', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      OfficeName: {
        field: 'OfficeName',
        type: Sequelize.STRING,
        allowNull: true
      },
      Pincode: {
        field: 'Pincode',
        type: Sequelize.INTEGER,
        allowNull: true
      },
      OfficeType: {
        field: 'OfficeType',
        type: Sequelize.STRING,
        allowNull: true
      },
      DeliveryStatus: {
        field: 'DeliveryStatus',
        type: Sequelize.STRING,
        allowNull: true
      },
      Division: {
        field: 'DivisionName',
        type: Sequelize.STRING,
        allowNull: true
      },
      Region: {
        field: 'RegionName',
        type: Sequelize.STRING,
        allowNull: true
      },
      Circle: {
        field: 'CircleName',
        type: Sequelize.STRING,
        allowNull: true
      },
      Block: {
        field: 'Block',
        type: Sequelize.STRING,
        allowNull: true
      },
      District: {
        field: 'DistrictName',
        type: Sequelize.STRING,
        allowNull: true
      },
      State: {
        field: 'StateName',
        type: Sequelize.STRING,
        allowNull: true
      },
      Telephone: {
        field: 'Telephone',
        type: Sequelize.STRING,
        allowNull: true
      },
      RelatedSuboffice: {
        field: 'RelatedSuboffice',
        type: Sequelize.STRING,
        allowNull: true
      },
      RelatedHeadoffice: {
        field: 'RelatedHeadoffice',
        type: Sequelize.STRING,
        allowNull: true
      },
      Country: {
        field: 'Country',
        type: Sequelize.STRING,
        allowNull: true
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Countries');
  }
};