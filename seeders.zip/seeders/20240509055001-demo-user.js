'use strict';

const { User, Role, UserPermissionRoles } = require('../models');
const bcrypt = require('bcrypt');
const path = require("path");
module.exports = {
  up: async (queryInterface, Sequelize) => {
    const password = '123';
    const hashedPassword = await bcrypt.hash(password, 10);
    let ArrayRole = ['Super Admin', 'Admin', 'Instructor', 'Student', 'Guest/Viewer', 'Sale Department', 'Telecaller Department', 'Telecaller Team', 'Front Desk', 'Counselor Department', 'Account Department']
    // Find or create the role "Super Admin"
    let department
    /*     for (let index = 0; index < ArrayRole.length; index++) {
          department = await queryInterface.bulkInsert('Roles', [{
            Name: ArrayRole[index],
            createdAt: new Date(),
            updatedAt: new Date(),
          }], { returning: true });
        }
     */

    let user;
    /*   if (departments) {
        user = await queryInterface.bulkInsert('Users', [{
          name: 'Super Admin',
          userName: 'SuperAdmin001',
          phoneNumber: '1234567890',
          email: 'superadmin@gmail.com',
          password: hashedPassword,
          departmentName: departments[0].Name,
          roleName: 'Users Admin',
          assignToUsers: 1,
          image: '2024-04-30T06-55-47.882Z-2.jpg',
          src: path.join(__dirname, '..', 'uploads', '2024-04-30T06-55-47.882Z-2.jpg'),
          active: 1,
          createdAt: new Date(),
          updatedAt: new Date(),
        }], { returning: true });
      } */
    /*       let departments = await Role.findOne({ where: { Name: 'Super Admin' } });
          let users = await User.findOne({ where: { departmentName: 'Super Admin' } }); */
    let departments = await Role.findAll({});
    let users = await User.findAll({});
    let userPermissionRoles


    if (users[0].departmentName == 'Super Admin' && departments[0].Name == 'Super Admin') {
      userPermissionRoles = await queryInterface.bulkInsert('UserPermissionRoles', [{
        RoleId: departments[0].id,
        UserId: users[0].id,
        Create: 1,
        Read: 1,
        Update: 1,
        Delete: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      }]);
    }
    console.log(userPermissionRoles);




  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('Users', null, {});
    await queryInterface.bulkDelete('Roles', null, {});
    await queryInterface.bulkDelete('UserPermissionRoles', null, {});
  }
};

